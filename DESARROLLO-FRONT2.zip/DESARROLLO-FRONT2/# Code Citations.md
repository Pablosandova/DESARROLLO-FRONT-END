# Code Citations

## License: unknown
https://github.com/sanguino09/Spartan-MMA/tree/138715ade4c0f21a10c59f14931cddffe82e1c57/prodCard.html

```
.html -->
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0
```


## License: unknown
https://github.com/LeandroBarone/NN-Piedra-Papel-Tijera-Lagarto-Spock/tree/510cd8dc2f6d8cf6e5bdbad80d674f206cc0e380/index.html

```
->
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
```


## License: unknown
https://github.com/Nantesaurus/muni/tree/950d622eee6421da54ca84a33b7cd26d9a423fd3/index.html

```
DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Municipalidad
```


## License: unknown
https://github.com/EloyLatorre/proyectoBootrstrapGIM/tree/c8967dbc9befe706889f706aa4b96633cfee0056/index.html

```
"invalid-feedback">Por favor ingresa tu nombre.</div>
        </div>
        <div class="mb-3">
          <label for="email" class="form-label">Correo electrónico</label>
          <input type=
```


## License: unknown
https://github.com/IgmarLS/bodegas-hermanos-segarra/tree/e4693b810b63786287074fa72d4d566d5c025de0/contact-us.html

```
</div>
        <div class="mb-3">
          <label for="email" class="form-label">Correo electrónico</label>
          <input type="email" class="form-control" id="email" required
```

